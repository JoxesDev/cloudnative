import {
  BrowserPerformanceMeasurement
} from "./chunk-HRIT2FOY.js";
import "./chunk-RQBZITXC.js";
export {
  BrowserPerformanceMeasurement
};
